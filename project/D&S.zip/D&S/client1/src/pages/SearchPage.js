import React from "react";

function SearchPage() {
  return (
    <div className="container">
      <h1>Search</h1>
      <input type="text" className="form-control" placeholder="Search for clothing..." />
    </div>
  );
}

export default SearchPage;
